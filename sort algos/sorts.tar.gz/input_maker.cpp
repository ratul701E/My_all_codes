#include<bits/stdc++.h>
using namespace std;
int main() {
	ofstream f("input.txt");
	long long s = 500000;
	while(s--) {
		f << rand()%100+1 << endl;
	}
	
}
